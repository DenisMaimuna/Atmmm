using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace StatisticsApp
{
    public partial class Form1 : Form
    {
        List<double> numbers = new List<double>();
        Dictionary<double, int> frequencies = new Dictionary<double, int>();

        public Form1()
        {
            InitializeComponent();
        }

        // Числата се разделят с интервал или ; . Десетичната запетая е позволена.
        private bool ReadNumbers()
        {
            numbers.Clear();
            string input = txtNumbers.Text.Trim();
            if (input == "")
            {
                MessageBox.Show("Въведете поне едно число.");
                return false;
            }

            // Поддържа и списък като 2, 3, 3, 5 (запетая + интервал).
            string[] parts = System.Text.RegularExpressions.Regex.Split(input, @"[;\s]+|,(?=\s)");
            foreach (string part in parts)
            {
                if (part == "") continue;
                double number;
                string value = part.Replace(',', '.');
                if (!double.TryParse(value, NumberStyles.Float, CultureInfo.InvariantCulture, out number)
                    || double.IsNaN(number) || double.IsInfinity(number))
                {
                    MessageBox.Show("Невалидно число: " + part + "\nРазделяйте числата с интервал или ;");
                    numbers.Clear();
                    return false;
                }
                numbers.Add(number);
            }
            if (numbers.Count == 0)
            {
                MessageBox.Show("Въведете поне едно число.");
                return false;
            }
            numbers.Sort();
            frequencies = numbers.GroupBy(x => x).ToDictionary(g => g.Key, g => g.Count());
            return true;
        }

        private bool EnsureNumbers()
        {
            if (ReadNumbers()) return true;
            lblAnswer.Text = "Отговор:";
            chart1.Series.Clear();
            return false;
        }

        private void ShowAllResults()
        {
            int n = numbers.Count;
            double median = n % 2 == 1 ? numbers[n / 2] :
                numbers[n / 2 - 1] / 2 + numbers[n / 2] / 2;
            int maxCount = frequencies.Values.Max();
            string modes = string.Join(", ", frequencies.Where(x => x.Value == maxCount)
                    .OrderBy(x => x.Key).Select(x => FormatNumber(x.Key)));

            lblAnswer.Text = "Средно: " + FormatNumber(numbers.Average()) +
                "    Медиана: " + FormatNumber(median) +
                "    Мода: " + modes;
        }

        private string FormatNumber(double value)
        {
            return value.ToString("0.####", new CultureInfo("bg-BG"));
        }

        private void btnShow_Click(object sender, EventArgs e)
        {
            if (!EnsureNumbers()) return;
            ShowAllResults();
            DrawChart(SeriesChartType.Column);
        }

        private void btnMean_Click(object sender, EventArgs e)
        {
            if (!EnsureNumbers()) return;
            lblAnswer.Text = "Средно аритметично: " + FormatNumber(numbers.Average());
        }

        private void btnMedian_Click(object sender, EventArgs e)
        {
            if (!EnsureNumbers()) return;
            int n = numbers.Count;
            double median = n % 2 == 1 ? numbers[n / 2] : (numbers[n / 2 - 1] / 2 + numbers[n / 2] / 2);
            lblAnswer.Text = "Медиана: " + FormatNumber(median);
        }

        private void btnMode_Click(object sender, EventArgs e)
        {
            if (!EnsureNumbers()) return;
            int maxCount = frequencies.Values.Max();
            string modes = string.Join(", ", frequencies.Where(x => x.Value == maxCount)
                .OrderBy(x => x.Key).Select(x => FormatNumber(x.Key)));
            lblAnswer.Text = "Мода: " + modes;
        }

        private void DrawChart(SeriesChartType type)
        {
            chart1.Series.Clear();
            chart1.ChartAreas[0].AxisX.Title = "Число";
            chart1.ChartAreas[0].AxisY.Title = "Честота";
            chart1.ChartAreas[0].AxisX.Interval = 1;
            Series series = new Series("Честота");
            series.ChartType = type;
            series.IsValueShownAsLabel = true;
            series.BorderWidth = 3;
            series.MarkerStyle = MarkerStyle.Circle;
            series.MarkerSize = 7;
            foreach (var item in frequencies.OrderBy(x => x.Key))
                series.Points.AddXY(FormatNumber(item.Key), item.Value);
            chart1.Series.Add(series);
        }

        private void btnColumn_Click(object sender, EventArgs e)
        {
            if (EnsureNumbers()) { ShowAllResults(); DrawChart(SeriesChartType.Column); }
        }

        private void btnPie_Click(object sender, EventArgs e)
        {
            if (EnsureNumbers()) { ShowAllResults(); DrawChart(SeriesChartType.Pie); }
        }

        private void btnLine_Click(object sender, EventArgs e)
        {
            if (EnsureNumbers()) { ShowAllResults(); DrawChart(SeriesChartType.Line); }
        }
    }
}
