using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace StatisticsApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            string[] parts = txtNumbers.Text.Split(new char[] { ',', ';', ' ', '\n', '\r', '\t' }, StringSplitOptions.RemoveEmptyEntries);
            List<double> numbers = new List<double>();

            foreach (string part in parts)
            {
                double number;
                if (!double.TryParse(part.Replace('.', ','), out number) || double.IsNaN(number) || double.IsInfinity(number))
                {
                    MessageBox.Show("Въведи само числа, разделени със запетая или интервал.");
                    return;
                }
                numbers.Add(number);
            }

            if (numbers.Count == 0)
            {
                MessageBox.Show("Първо въведи числа!");
                return;
            }

            numbers.Sort();
            double average = numbers.Average();
            int middle = numbers.Count / 2;
            double median = numbers.Count % 2 == 1
                ? numbers[middle]
                : (numbers[middle - 1] + numbers[middle]) / 2;

            var frequencies = numbers.GroupBy(x => x)
                                     .Select(g => new { Number = g.Key, Count = g.Count() })
                                     .ToList();
            int maxCount = frequencies.Max(x => x.Count);
            string modes = string.Join(", ", frequencies.Where(x => x.Count == maxCount)
                                                         .Select(x => x.Number.ToString()));

            lblAverage.Text = "Средно аритметично: " + average.ToString("0.##");
            lblMedian.Text = "Медиана: " + median.ToString("0.##");
            lblMode.Text = maxCount == 1 ? "Мода: няма" : "Мода: " + modes;

            chartHistogram.Series[0].Points.Clear();
            chartPie.Series[0].Points.Clear();
            chartPolygon.Series[0].Points.Clear();

            foreach (var item in frequencies)
            {
                string label = item.Number.ToString();
                chartHistogram.Series[0].Points.AddXY(label, item.Count);
                chartPie.Series[0].Points.AddXY(label, item.Count);
                chartPolygon.Series[0].Points.AddXY(label, item.Count);
            }
        }
    }
}
