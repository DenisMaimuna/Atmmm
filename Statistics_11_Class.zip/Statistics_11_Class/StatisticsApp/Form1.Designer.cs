namespace StatisticsApp
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblInstructions;
        private System.Windows.Forms.TextBox txtNumbers;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Label lblAverage;
        private System.Windows.Forms.Label lblMedian;
        private System.Windows.Forms.Label lblMode;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartHistogram;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartPie;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartPolygon;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea area1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.ChartArea area2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.ChartArea area3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title1 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.Windows.Forms.DataVisualization.Charting.Title title2 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.Windows.Forms.DataVisualization.Charting.Title title3 = new System.Windows.Forms.DataVisualization.Charting.Title();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblInstructions = new System.Windows.Forms.Label();
            this.txtNumbers = new System.Windows.Forms.TextBox();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.lblAverage = new System.Windows.Forms.Label();
            this.lblMedian = new System.Windows.Forms.Label();
            this.lblMode = new System.Windows.Forms.Label();
            this.chartHistogram = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chartPie = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chartPolygon = new System.Windows.Forms.DataVisualization.Charting.Chart();
            ((System.ComponentModel.ISupportInitialize)(this.chartHistogram)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartPie)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartPolygon)).BeginInit();
            this.SuspendLayout();
            this.BackColor = System.Drawing.Color.FromArgb(235, 243, 252);
            this.ClientSize = new System.Drawing.Size(1140, 750);
            this.MinimumSize = new System.Drawing.Size(1156, 789);
            this.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Статистика на редица от числа";
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 23F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(22, 64, 113);
            this.lblTitle.Location = new System.Drawing.Point(26, 20);
            this.lblTitle.Text = "Статистика на редица от числа";
            this.lblInstructions.AutoSize = true;
            this.lblInstructions.Location = new System.Drawing.Point(30, 90);
            this.lblInstructions.Text = "Въведи числа, разделени със запетая или интервал:";
            this.txtNumbers.Location = new System.Drawing.Point(33, 126);
            this.txtNumbers.Size = new System.Drawing.Size(780, 32);
            this.txtNumbers.Text = "2, 3, 3, 5, 7, 7, 7, 9";
            this.btnCalculate.Location = new System.Drawing.Point(835, 123);
            this.btnCalculate.Size = new System.Drawing.Size(255, 40);
            this.btnCalculate.BackColor = System.Drawing.Color.FromArgb(30, 103, 190);
            this.btnCalculate.ForeColor = System.Drawing.Color.White;
            this.btnCalculate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCalculate.Text = "Изчисли";
            this.btnCalculate.UseVisualStyleBackColor = false;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            this.lblAverage.AutoSize = true;
            this.lblAverage.Location = new System.Drawing.Point(33, 188);
            this.lblAverage.Text = "Средно аритметично: -";
            this.lblMedian.AutoSize = true;
            this.lblMedian.Location = new System.Drawing.Point(410, 188);
            this.lblMedian.Text = "Медиана: -";
            this.lblMode.AutoSize = true;
            this.lblMode.Location = new System.Drawing.Point(740, 188);
            this.lblMode.Text = "Мода: -";
            area1.AxisX.Title = "Число";
            area1.AxisY.Title = "Честота";
            area1.AxisY.Interval = 1;
            this.chartHistogram.ChartAreas.Add(area1);
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Column;
            series1.Color = System.Drawing.Color.FromArgb(42, 125, 207);
            series1.IsValueShownAsLabel = true;
            this.chartHistogram.Series.Add(series1);
            title1.Text = "Хистограма (честоти)";
            title1.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.chartHistogram.Titles.Add(title1);
            this.chartHistogram.Location = new System.Drawing.Point(25, 250);
            this.chartHistogram.Size = new System.Drawing.Size(535, 215);
            area2.Area3DStyle.Enable3D = false;
            this.chartPie.ChartAreas.Add(area2);
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie;
            series2.IsValueShownAsLabel = true;
            series2.Label = "#VALX: #PERCENT{P0}";
            this.chartPie.Series.Add(series2);
            title2.Text = "Кръгова диаграма";
            title2.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.chartPie.Titles.Add(title2);
            this.chartPie.Location = new System.Drawing.Point(575, 250);
            this.chartPie.Size = new System.Drawing.Size(535, 215);
            area3.AxisX.Title = "Число";
            area3.AxisY.Title = "Честота";
            area3.AxisY.Interval = 1;
            this.chartPolygon.ChartAreas.Add(area3);
            series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series3.BorderWidth = 3;
            series3.MarkerStyle = System.Windows.Forms.DataVisualization.Charting.MarkerStyle.Circle;
            series3.MarkerSize = 9;
            series3.Color = System.Drawing.Color.FromArgb(27, 146, 140);
            series3.IsValueShownAsLabel = true;
            this.chartPolygon.Series.Add(series3);
            title3.Text = "Честотен полигон";
            title3.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.chartPolygon.Titles.Add(title3);
            this.chartPolygon.Location = new System.Drawing.Point(300, 475);
            this.chartPolygon.Size = new System.Drawing.Size(535, 225);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.lblInstructions);
            this.Controls.Add(this.txtNumbers);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.lblAverage);
            this.Controls.Add(this.lblMedian);
            this.Controls.Add(this.lblMode);
            this.Controls.Add(this.chartHistogram);
            this.Controls.Add(this.chartPie);
            this.Controls.Add(this.chartPolygon);
            ((System.ComponentModel.ISupportInitialize)(this.chartHistogram)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartPie)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartPolygon)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
