using System;
using System.Drawing;
using System.Windows.Forms;

namespace ATM
{
    // Учебни данни. Не се свързва с истинска банка.
    static class Account
    {
        public static decimal Balance = 1000;
        public static string Pin = "1234";
    }

    public class ATMForm : Form
    {
        Panel area;
        Color blue = Color.FromArgb(0, 105, 190);
        Color darkBlue = Color.FromArgb(0, 52, 150);

        public ATMForm()
        {
            Text = "ATM - Банкомат";
            ClientSize = new Size(820, 520);
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            BackColor = blue;
            area = new Panel { Dock = DockStyle.Fill, BackColor = blue };
            Controls.Add(area);
            Welcome();
        }

        void Clear(string title)
        {
            area.Controls.Clear();
            Label heading = new Label
            {
                Text = title, Font = new Font("Segoe UI", 25, FontStyle.Bold),
                ForeColor = Color.White, TextAlign = ContentAlignment.MiddleCenter,
                Bounds = new Rectangle(20, 25, 780, 70)
            };
            area.Controls.Add(heading);
        }

        Button AddButton(string text, int x, int y, int width, Action click)
        {
            Button b = new Button
            {
                Text = text, Bounds = new Rectangle(x, y, width, 65),
                Font = new Font("Segoe UI", 15), BackColor = Color.White,
                ForeColor = darkBlue, FlatStyle = FlatStyle.Flat
            };
            b.FlatAppearance.BorderSize = 0;
            b.Click += (s, e) => click();
            area.Controls.Add(b);
            return b;
        }

        Label AddLabel(string text, int x, int y, int width)
        {
            Label label = new Label
            {
                Text = text, Bounds = new Rectangle(x, y, width, 40),
                Font = new Font("Segoe UI", 16), ForeColor = Color.White,
                TextAlign = ContentAlignment.MiddleCenter
            };
            area.Controls.Add(label);
            return label;
        }

        TextBox AddInput(int x, int y, bool password = false)
        {
            TextBox input = new TextBox
            {
                Bounds = new Rectangle(x, y, 280, 40),
                Font = new Font("Segoe UI", 18),
                UseSystemPasswordChar = password,
                TextAlign = HorizontalAlignment.Center
            };
            area.Controls.Add(input);
            return input;
        }

        void Welcome()
        {
            Clear("ОББ - Добре дошли!");
            AddLabel("Учебен банкомат", 260, 165, 300);
            AddButton("Влез в системата", 260, 270, 300, Login);
        }

        void Login()
        {
            Clear("Въведете ПИН");
            TextBox pin = AddInput(270, 175, true);
            AddButton("Вход", 270, 265, 280, () =>
            {
                if (pin.Text == Account.Pin) Menu();
                else MessageBox.Show("Грешен ПИН!");
            });
            AddButton("Отказ", 270, 355, 280, Welcome);
        }

        void Menu()
        {
            Clear("Главно меню");
            AddButton("Теглене", 80, 135, 290, () => Money(false));
            AddButton("Внасяне", 450, 135, 290, () => Money(true));
            AddButton("Проверка на баланс", 80, 235, 290, () =>
                MessageBox.Show("Наличност: " + Account.Balance.ToString("0.00") + " лв."));
            AddButton("Други услуги", 450, 235, 290, OtherServices);
            AddButton("Смяна на ПИН", 80, 335, 290, ChangePin);
            AddButton("Изход", 450, 335, 290, Welcome);
        }

        void Money(bool deposit)
        {
            Clear(deposit ? "Внасяне на пари" : "Теглене на пари");
            AddLabel("Въведете сума в лева:", 230, 130, 360);
            TextBox amount = AddInput(270, 195);
            AddButton("Потвърди", 270, 280, 280, () =>
            {
                decimal sum;
                if (!decimal.TryParse(amount.Text, out sum) || sum <= 0)
                {
                    MessageBox.Show("Въведете валидна положителна сума!");
                    return;
                }
                if (!deposit && sum > Account.Balance)
                {
                    MessageBox.Show("Недостатъчна наличност!");
                    return;
                }
                if (deposit) Account.Balance += sum;
                else Account.Balance -= sum;
                MessageBox.Show("Успешна операция! Баланс: " + Account.Balance.ToString("0.00") + " лв.");
                Menu();
            });
            AddButton("Назад", 270, 375, 280, Menu);
        }

        void ChangePin()
        {
            Clear("Смяна на ПИН");
            AddLabel("Нов ПИН (4 цифри):", 240, 135, 340);
            TextBox newPin = AddInput(270, 195, true);
            AddButton("Запази", 270, 280, 280, () =>
            {
                if (newPin.Text.Length != 4 || !IsDigits(newPin.Text))
                {
                    MessageBox.Show("ПИН трябва да съдържа точно 4 цифри!");
                    return;
                }
                Account.Pin = newPin.Text;
                MessageBox.Show("ПИН е променен успешно!");
                Menu();
            });
            AddButton("Назад", 270, 375, 280, Menu);
        }

        bool IsDigits(string value)
        {
            foreach (char c in value)
                if (c < '0' || c > '9') return false;
            return true;
        }

        void OtherServices()
        {
            Clear("Други услуги");
            AddButton("Справки", 40, 125, 300, () => MessageBox.Show("Баланс: " + Account.Balance.ToString("0.00") + " лв."));
            AddButton("Плащане чрез интернет", 480, 125, 300, () => NotAvailable());
            AddButton("Смяна на ПИН", 40, 215, 300, ChangePin);
            AddButton("Други суми", 480, 215, 300, () => Money(false));
            AddButton("Преводи", 40, 305, 300, () => NotAvailable());
            AddButton("Плащане на сметки", 480, 305, 300, () => NotAvailable());
            AddButton("B Pay", 40, 395, 300, () => NotAvailable());
            AddButton("Отказ", 480, 395, 300, Menu);
        }

        void NotAvailable()
        {
            MessageBox.Show("Тази услуга е демонстрационна.");
        }
    }
}
