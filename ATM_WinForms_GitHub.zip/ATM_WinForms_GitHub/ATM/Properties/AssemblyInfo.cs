using System.Reflection;
[assembly: AssemblyTitle("ATM")]
[assembly: AssemblyProduct("ATM School Project")]
[assembly: AssemblyVersion("1.0.0.0")]
