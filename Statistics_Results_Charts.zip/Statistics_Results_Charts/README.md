Статистика – Windows Forms .NET Framework 4.8

Отворете StatisticsApp.sln във Visual Studio.
Въведете числа, разделени с интервал или ; (напр. 1,5 2,5 4 5).
Show показва средно, медиана, всички моди и хистограма.
Column, Pie Chart и Line показват съответната диаграма и актуалните резултати.
Shift+F7 върху Form1.cs отваря Designer.
