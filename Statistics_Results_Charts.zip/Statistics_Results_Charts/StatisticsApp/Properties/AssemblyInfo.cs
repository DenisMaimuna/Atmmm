using System.Reflection;
[assembly: AssemblyTitle("StatisticsApp")]
[assembly: AssemblyVersion("1.0.0.0")]
