namespace StatisticsApp
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Label labelTitle;
        private System.Windows.Forms.TextBox txtNumbers;
        private System.Windows.Forms.Button btnShow;
        private System.Windows.Forms.Button btnMean;
        private System.Windows.Forms.Button btnMedian;
        private System.Windows.Forms.Button btnMode;
        private System.Windows.Forms.Label lblAnswer;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.Button btnColumn;
        private System.Windows.Forms.Button btnPie;
        private System.Windows.Forms.Button btnLine;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            this.labelTitle = new System.Windows.Forms.Label();
            this.txtNumbers = new System.Windows.Forms.TextBox();
            this.btnShow = new System.Windows.Forms.Button();
            this.btnMean = new System.Windows.Forms.Button();
            this.btnMedian = new System.Windows.Forms.Button();
            this.btnMode = new System.Windows.Forms.Button();
            this.lblAnswer = new System.Windows.Forms.Label();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.btnColumn = new System.Windows.Forms.Button();
            this.btnPie = new System.Windows.Forms.Button();
            this.btnLine = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.SuspendLayout();
            // labelTitle
            this.labelTitle.AutoSize = true;
            this.labelTitle.Font = new System.Drawing.Font("Segoe UI", 20F);
            this.labelTitle.Location = new System.Drawing.Point(26, 15);
            this.labelTitle.Text = "Въведете числа:";
            // txtNumbers
            this.txtNumbers.Font = new System.Drawing.Font("Segoe UI", 15F);
            this.txtNumbers.Location = new System.Drawing.Point(30, 68);
            this.txtNumbers.Size = new System.Drawing.Size(680, 34);
            this.txtNumbers.Text = "1,5 2,5 4 5";
            // btnShow
            this.btnShow.Location = new System.Drawing.Point(722, 67);
            this.btnShow.Size = new System.Drawing.Size(120, 39);
            this.btnShow.Text = "Show";
            this.btnShow.Click += new System.EventHandler(this.btnShow_Click);
            // btnMean
            this.btnMean.Location = new System.Drawing.Point(30, 120);
            this.btnMean.Size = new System.Drawing.Size(258, 95);
            this.btnMean.Text = "Средно\nаритметично";
            this.btnMean.Click += new System.EventHandler(this.btnMean_Click);
            // btnMedian
            this.btnMedian.Location = new System.Drawing.Point(297, 120);
            this.btnMedian.Size = new System.Drawing.Size(258, 95);
            this.btnMedian.Text = "Медиана";
            this.btnMedian.Click += new System.EventHandler(this.btnMedian_Click);
            // btnMode
            this.btnMode.Location = new System.Drawing.Point(564, 120);
            this.btnMode.Size = new System.Drawing.Size(278, 95);
            this.btnMode.Text = "Мода";
            this.btnMode.Click += new System.EventHandler(this.btnMode_Click);
            // lblAnswer
            this.lblAnswer.AutoEllipsis = true;
            this.lblAnswer.Font = new System.Drawing.Font("Segoe UI", 15F);
            this.lblAnswer.Location = new System.Drawing.Point(30, 226);
            this.lblAnswer.Size = new System.Drawing.Size(812, 58);
            this.lblAnswer.Text = "Отговор:";
            // chart1
            chartArea.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea);
            this.chart1.Location = new System.Drawing.Point(30, 291);
            this.chart1.Size = new System.Drawing.Size(650, 300);
            // btnColumn
            this.btnColumn.Location = new System.Drawing.Point(697, 301);
            this.btnColumn.Size = new System.Drawing.Size(145, 78);
            this.btnColumn.Text = "Column";
            this.btnColumn.Click += new System.EventHandler(this.btnColumn_Click);
            // btnPie
            this.btnPie.Location = new System.Drawing.Point(697, 397);
            this.btnPie.Size = new System.Drawing.Size(145, 78);
            this.btnPie.Text = "Pie Chart";
            this.btnPie.Click += new System.EventHandler(this.btnPie_Click);
            // btnLine
            this.btnLine.Location = new System.Drawing.Point(697, 493);
            this.btnLine.Size = new System.Drawing.Size(145, 78);
            this.btnLine.Text = "Line";
            this.btnLine.Click += new System.EventHandler(this.btnLine_Click);
            // Form1
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(875, 620);
            this.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Статистика";
            this.Controls.Add(this.labelTitle);
            this.Controls.Add(this.txtNumbers);
            this.Controls.Add(this.btnShow);
            this.Controls.Add(this.btnMean);
            this.Controls.Add(this.btnMedian);
            this.Controls.Add(this.btnMode);
            this.Controls.Add(this.lblAnswer);
            this.Controls.Add(this.chart1);
            this.Controls.Add(this.btnColumn);
            this.Controls.Add(this.btnPie);
            this.Controls.Add(this.btnLine);
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
