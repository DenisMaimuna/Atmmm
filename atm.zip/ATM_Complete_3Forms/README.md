# ATM – Windows Forms (.NET Framework 4.8)

Готов проект с **три форми**, код и файлове за Visual Studio Designer.

## Файлове
- `ATM.sln` – отваря целия проект във Visual Studio.
- `ATM/Form1.cs` + `ATM/Form1.Designer.cs` – начален екран, бутон „Влез в системата“.
- `ATM/Form2.cs` + `ATM/Form2.Designer.cs` – главно меню, теглене, внасяне, баланс.
- `ATM/Form3.cs` + `ATM/Form3.Designer.cs` – други услуги и смяна на ПИН.
- `ATM/Bank.cs` – общ баланс и ПИН.
- `ATM/Program.cs` – стартира Form1.
- `ATM/ATM.csproj` – проектен файл.

## Отваряне
1. Разархивирайте ZIP файла.
2. В Windows отворете `ATM.sln` с Visual Studio 2022.
3. В Solution Explorer: десен бутон на `Form1.cs`, `Form2.cs` или `Form3.cs` → **View Designer** (Shift+F7).
4. За кода: десен бутон → **View Code** (F7).
5. За стартиране: **F5**.

ПИН за учебния проект: `1234`; начален баланс: `1000 лв.`. Влизането е без ПИН, а операциите изискват ПИН. Данните са само в паметта и се нулират при ново стартиране.
