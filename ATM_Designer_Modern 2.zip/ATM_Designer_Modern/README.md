# ATM – Modern Dark Design (Windows Forms .NET Framework 4.8)

Три форми с Windows Forms Designer:
- Form1 – начален екран без ПИН
- Form2 – главно меню, теглене и внасяне с ПИН, баланс
- Form3 – други услуги, смяна на ПИН

Дизайн: тъмен графит, ментовозелени бутони и акценти.

Отворете ATM.sln във Visual Studio 2022 на Windows. В Solution Explorer изберете Form1.cs, Form2.cs или Form3.cs → View Designer (Shift+F7). Стартирайте с F5.

Демо ПИН: 1234; начален баланс: 1000 лв. Данните не се запазват след затваряне.
