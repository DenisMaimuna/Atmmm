using System;
using System.Windows.Forms;
using Microsoft.VisualBasic;
namespace ATM
{
    public partial class Form2 : Form
    {
        public Form2() { InitializeComponent(); }

        // ПИН се иска само при операция, не при влизане в менюто.
        private bool CheckPin()
        {
            using (Form window = new Form())
            {
                window.Text = "Потвърждение с ПИН";
                window.Width = 320;
                window.Height = 170;
                window.StartPosition = FormStartPosition.CenterParent;
                window.FormBorderStyle = FormBorderStyle.FixedDialog;
                window.MaximizeBox = false;
                window.MinimizeBox = false;
                Label label = new Label() { Text = "Въведете ПИН:", Left = 20, Top = 15, Width = 250 };
                TextBox input = new TextBox() { Left = 20, Top = 45, Width = 260, PasswordChar = '*' };
                Button ok = new Button() { Text = "Потвърди", Left = 100, Top = 80, Width = 100, DialogResult = DialogResult.OK };
                window.Controls.Add(label);
                window.Controls.Add(input);
                window.Controls.Add(ok);
                window.AcceptButton = ok;
                if (window.ShowDialog(this) != DialogResult.OK) return false;
                if (input.Text == Bank.Pin) return true;
                MessageBox.Show("Грешен ПИН!");
                return false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!CheckPin()) return;
            string text = Interaction.InputBox("Сума за теглене (лв.):", "Теглене");
            decimal amount;
            if (!decimal.TryParse(text, out amount) || amount <= 0) return;
            if (amount > Bank.Balance) { MessageBox.Show("Недостатъчна наличност!"); return; }
            Bank.Balance -= amount;
            MessageBox.Show("Изтеглени: " + amount + " лв.\nБаланс: " + Bank.Balance + " лв.");
        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (!CheckPin()) return;
            string text = Interaction.InputBox("Сума за внасяне (лв.):", "Внасяне");
            decimal amount;
            if (!decimal.TryParse(text, out amount) || amount <= 0) return;
            Bank.Balance += amount;
            MessageBox.Show("Внесени: " + amount + " лв.\nБаланс: " + Bank.Balance + " лв.");
        }
        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Наличност: " + Bank.Balance + " лв.");
        }
        private void button4_Click(object sender, EventArgs e)
        {
            new Form3().Show();
            this.Hide();
        }
        private void button5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
