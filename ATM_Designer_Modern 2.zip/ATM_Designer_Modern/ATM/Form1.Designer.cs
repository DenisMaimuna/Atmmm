﻿namespace ATM
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label subtitle;
        private System.Windows.Forms.Panel accent;
        private System.Windows.Forms.Button button1;
        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.subtitle = new System.Windows.Forms.Label();
            this.accent = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            this.accent.BackColor = System.Drawing.Color.FromArgb(67, 224, 163);
            this.accent.Location = new System.Drawing.Point(42, 38);
            this.accent.Name = "accent";
            this.accent.Size = new System.Drawing.Size(62, 5);
            this.subtitle.AutoSize = false;
            this.subtitle.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.subtitle.ForeColor = System.Drawing.Color.FromArgb(159, 178, 190);
            this.subtitle.Location = new System.Drawing.Point(45, 125);
            this.subtitle.Name = "subtitle";
            this.subtitle.Size = new System.Drawing.Size(660, 32);
            this.subtitle.Text = "Добре дошли! Изберете старт, за да продължите.";
            // label1
            this.label1.AutoSize = false;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 27F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(42, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(616, 65);
            this.label1.Text = "Твоите пари. Твоят избор.";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // button1
            this.button1.BackColor = System.Drawing.Color.FromArgb(67, 224, 163);
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.button1.ForeColor = System.Drawing.Color.FromArgb(19, 26, 37);
            this.button1.Location = new System.Drawing.Point(45, 245);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(400, 78);
            this.button1.Text = "ВЛЕЗ В СИСТЕМАТА";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // Form
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(19, 26, 37);
            this.ClientSize = new System.Drawing.Size(760, 520);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.subtitle);
            this.Controls.Add(this.accent);
            this.Controls.Add(this.button1);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Name = "Form1";
            this.Text = "ATM - Добре дошли в банкомата";
            this.ResumeLayout(false);
        }
    }
}
