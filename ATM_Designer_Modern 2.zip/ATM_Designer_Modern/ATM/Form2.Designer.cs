﻿namespace ATM
{
    partial class Form2
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label subtitle;
        private System.Windows.Forms.Panel accent;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.subtitle = new System.Windows.Forms.Label();
            this.accent = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            this.accent.BackColor = System.Drawing.Color.FromArgb(67, 224, 163);
            this.accent.Location = new System.Drawing.Point(42, 38);
            this.accent.Name = "accent";
            this.accent.Size = new System.Drawing.Size(62, 5);
            this.subtitle.AutoSize = false;
            this.subtitle.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.subtitle.ForeColor = System.Drawing.Color.FromArgb(159, 178, 190);
            this.subtitle.Location = new System.Drawing.Point(45, 125);
            this.subtitle.Name = "subtitle";
            this.subtitle.Size = new System.Drawing.Size(660, 32);
            this.subtitle.Text = "ATM  /  Сигурно и лесно банкиране";
            // label1
            this.label1.AutoSize = false;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 27F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(42, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(616, 65);
            this.label1.Text = "Главно меню";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // button1
            this.button1.BackColor = System.Drawing.Color.FromArgb(67, 224, 163);
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.button1.ForeColor = System.Drawing.Color.FromArgb(19, 26, 37);
            this.button1.Location = new System.Drawing.Point(45, 190);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(325, 80);
            this.button1.Text = "Теглене";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // button2
            this.button2.BackColor = System.Drawing.Color.FromArgb(221, 247, 235);
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.button2.ForeColor = System.Drawing.Color.FromArgb(19, 26, 37);
            this.button2.Location = new System.Drawing.Point(390, 190);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(325, 80);
            this.button2.Text = "Внасяне";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // button3
            this.button3.BackColor = System.Drawing.Color.FromArgb(221, 247, 235);
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.button3.ForeColor = System.Drawing.Color.FromArgb(19, 26, 37);
            this.button3.Location = new System.Drawing.Point(45, 290);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(325, 80);
            this.button3.Text = "Проверка на баланс";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // button4
            this.button4.BackColor = System.Drawing.Color.FromArgb(221, 247, 235);
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.button4.ForeColor = System.Drawing.Color.FromArgb(19, 26, 37);
            this.button4.Location = new System.Drawing.Point(390, 290);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(325, 80);
            this.button4.Text = "Други услуги";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // button5
            this.button5.BackColor = System.Drawing.Color.FromArgb(52, 65, 80);
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Location = new System.Drawing.Point(45, 407);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(670, 62);
            this.button5.Text = "Изход";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // Form
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(19, 26, 37);
            this.ClientSize = new System.Drawing.Size(760, 520);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.subtitle);
            this.Controls.Add(this.accent);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button5);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Name = "Form2";
            this.Text = "ATM - Главно меню";
            this.ResumeLayout(false);
        }
    }
}
