namespace ATM
{
    public static class Bank
    {
        public static decimal Balance = 1000;
        public static string Pin = "1234";
    }
}
