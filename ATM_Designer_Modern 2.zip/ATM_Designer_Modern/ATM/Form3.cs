using System;
using System.Windows.Forms;
using Microsoft.VisualBasic;
namespace ATM
{
    public partial class Form3 : Form
    {
        public Form3() { InitializeComponent(); }
        private bool CheckPin()
        {
            // Проверка за ПИН чрез прозорец (учебна версия).
            string pin = Interaction.InputBox("Въведете ПИН:", "Потвърждение");
            if (pin == Bank.Pin) return true;
            if (pin != "") MessageBox.Show("Грешен ПИН!");
            return false;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Баланс: " + Bank.Balance + " лв.");
        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (CheckPin()) MessageBox.Show("Услугата не е налична в учебната версия.");
        }
        private void button3_Click(object sender, EventArgs e)
        {
            if (!CheckPin()) return;
            string newPin = Interaction.InputBox("Въведете нов 4-цифрен ПИН:", "Смяна на ПИН");
            if (newPin.Length == 4 && int.TryParse(newPin, out _))
            {
                Bank.Pin = newPin;
                MessageBox.Show("ПИН кодът е променен!");
            }
            else if (newPin != "") MessageBox.Show("ПИН трябва да съдържа 4 цифри.");
        }
        private void button4_Click(object sender, EventArgs e)
        {
            if (CheckPin()) MessageBox.Show("Изберете 'Теглене' от главното меню.");
        }
        private void button5_Click(object sender, EventArgs e)
        {
            if (CheckPin()) MessageBox.Show("Преводите не са налични в учебната версия.");
        }
        private void button6_Click(object sender, EventArgs e)
        {
            if (CheckPin()) MessageBox.Show("Плащането на сметки не е налично в учебната версия.");
        }
        private void button7_Click(object sender, EventArgs e)
        {
            if (CheckPin()) MessageBox.Show("B Pay не е налично в учебната версия.");
        }
        private void button8_Click(object sender, EventArgs e)
        {
            new Form2().Show();
            this.Close();
        }
    }
}
